import json
import os
import boto3
import random
import datetime
import pandas as pd
import yfinance as yf
from time import sleep

REGION = os.environ['REGION']
StreamName=os.environ['StreamName']

kinesis = boto3.client('kinesis',REGION)

start_date = datetime.date(2022,5,2)
end_date = datetime.date(2022,5,3)

tickers = ['FB','SHOP','BYND','NFLX','PINS','SQ','TTD','OKTA','SNAP','DDOG']
high = 'High'
low = 'Low'

stocks=yf.download(tickers = tickers, start = start_date, end = end_date,
               interval='5m', rounding=True).reset_index()


def lambda_handler(event, context):
    for ticker in tickers:
        for i in range(len(stocks)):
            data={}
            data['high']=stocks[high][ticker][i]
            data['low']=stocks[low][ticker][i]
            data['ts']=str(stocks['Datetime'][i])
            data['name']=ticker
            stocksdata=json.dumps(data)+"\n"
            output = kinesis.put_record(
                        StreamName=StreamName,
                        Data=stocksdata,
                        PartitionKey="partitionkey")
            print(output)
            sleep(1)

    return {
        'statusCode': 200,
        'body': json.dumps('Done!')
    }